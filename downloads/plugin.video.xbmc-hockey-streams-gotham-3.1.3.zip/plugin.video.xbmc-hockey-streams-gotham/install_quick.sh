#!/bin/bash
set -x

export LOCATION=/Users/philippe/Library/AppSupp/Kodi/addons/plugin.video.xbmc-hockey-streams-gotham
cp -Rp * $LOCATION/. 
